# boot message auto sender
