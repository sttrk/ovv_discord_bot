# static debug messages
BOOT_OK_MSG = 'Boot sequence completed.'
