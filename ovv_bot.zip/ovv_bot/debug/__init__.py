# debug/__init__.py
# Debug パッケージの初期化は行わない。
# bot.py から必要なモジュールを直接 import させる。
